require.context('../../images', true);
// const imagePath = (name) => images(name, true);
require.context('bootstrap-icons/icons', true);
